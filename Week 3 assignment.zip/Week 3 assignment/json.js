//William L. Walker
//August 17, 2012
//Project 3 Assignment
//JSON project

var json = {

	"students": [

		{	"stuNum": "00121",
		
			"name" 	: "Damon",
			
			"grade":  87
			
		},
		
		{	"stuNum":  "00122",
		
			"name"	:  "Francine",
			
			"grade"	:  100
		},
		
		{

			"stuNum": "00123",

			"name": "Jacob",

			"grade": 89

		},

		{

			"stuNum": "00124",

			"name": "Stacy",

			"grade": 95

		},

		{

			"stuNum": "00125",

			"name": "Jace",

			"grade": 90

		},

		{

			"stuNum": "00126",

			"name": "Jadriaane",

			"grade": 97

		},

		{

			"stuNum": "00127",

			"name": "Hezekiah",

			"grade": 77

		},

		{

			"stuNum": "00128",

			"name": "Crystal",

			"grade": 79

		},

		{

			"stuNum": "00129",

			"name": "Orlando",

			"grade": 90

		},

		{

			"stuNum": "00121",

			"name": "Kim",

			"grade": 100

		},

		{

			"stuNum": "00122",

			"name": "Randi",

			"grade": 94

		},

		{

			"stuNum": "00120",

			"name": "Jordan",

			"grade": 96

		},

	]

};

